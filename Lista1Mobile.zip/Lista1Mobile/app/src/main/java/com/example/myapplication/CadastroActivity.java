package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class CadastroActivity extends AppCompatActivity {

    private EditText editNome, editIdade, editUF, editCidade, editTelefone, editEmail;
    private RadioGroup radioGroupTamanho;
    private CheckBox checkVermelho, checkAzul, checkVerde, checkPreto;
    private Button buttonCadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        editNome = findViewById(R.id.editNome);
        editIdade = findViewById(R.id.editIdade);
        editUF = findViewById(R.id.editUF);
        editCidade = findViewById(R.id.editCidade);
        editTelefone = findViewById(R.id.editTelefone);
        editEmail = findViewById(R.id.editEmail);
        radioGroupTamanho = findViewById(R.id.radioGroupTamanho);
        checkVermelho = findViewById(R.id.checkVermelho);
        checkAzul = findViewById(R.id.checkAzul);
        checkVerde = findViewById(R.id.checkVerde);
        checkPreto = findViewById(R.id.checkPreto);
        buttonCadastrar = findViewById(R.id.buttonCadastrar);

        buttonCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cadastrarUsuario();
            }
        });
    }

    private void cadastrarUsuario() {
        String nome = editNome.getText().toString();
        String idade = editIdade.getText().toString();
        String uf = editUF.getText().toString();
        String cidade = editCidade.getText().toString();
        String telefone = editTelefone.getText().toString();
        String email = editEmail.getText().toString();

        int tamanhoId = radioGroupTamanho.getCheckedRadioButtonId();
        RadioButton radioTamanho = findViewById(tamanhoId);
        String tamanho = radioTamanho.getText().toString();

        StringBuilder cores = new StringBuilder();
        if (checkVermelho.isChecked()) cores.append("Vermelho, ");
        if (checkAzul.isChecked()) cores.append("Azul, ");
        if (checkVerde.isChecked()) cores.append("Verde, ");
        if (checkPreto.isChecked()) cores.append("Preto, ");

        if (cores.length() > 0) {
            cores.delete(cores.length() - 2, cores.length()); // Remove a última vírgula e espaço
        }

        String mensagem = "Nome: " + nome + "\nIdade: " + idade + "\nUF: " + uf + "\nCidade: " + cidade + "\nTelefone: " + telefone + "\nEmail: " + email + "\nTamanho: " + tamanho + "\nCores: " + cores.toString();

        Toast.makeText(this, mensagem, Toast.LENGTH_LONG).show();
    }
}
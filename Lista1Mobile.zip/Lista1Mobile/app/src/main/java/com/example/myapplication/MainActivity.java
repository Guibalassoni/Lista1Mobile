package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button buttonExercicio1, buttonExercicio2, buttonExercicio3, buttonExercicio4, buttonExercicio5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonExercicio1 = findViewById(R.id.buttonExercicio1);
        buttonExercicio2 = findViewById(R.id.buttonExercicio2);
        buttonExercicio3 = findViewById(R.id.buttonExercicio3);
        buttonExercicio4 = findViewById(R.id.buttonExercicio4);
        buttonExercicio5 = findViewById(R.id.buttonExercicio5);

        buttonExercicio1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iniciarActivity(Exercicio1Activity.class);
            }
        });

        buttonExercicio2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iniciarActivity(CalculadoraActivity.class);
            }
        });

        buttonExercicio3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iniciarActivity(CadastroActivity.class);
            }
        });

        buttonExercicio4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iniciarActivity(NomeCheckboxActivity.class);
            }
        });

        buttonExercicio5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iniciarActivity(PreferenciasActivity.class);
            }
        });
    }

    private void iniciarActivity(Class<?> activityClass) {
        Intent intent = new Intent(this, activityClass);
        startActivity(intent);
    }
}
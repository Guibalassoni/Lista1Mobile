package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;

public class NomeCheckboxActivity extends AppCompatActivity {

    private EditText editNome;
    private Button buttonGerarCheckboxes;
    private LinearLayout linearLayoutCheckboxes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nome_checkbox);

        editNome = findViewById(R.id.editNome);
        buttonGerarCheckboxes = findViewById(R.id.buttonGerarCheckboxes);
        linearLayoutCheckboxes = findViewById(R.id.linearLayoutCheckboxes);

        buttonGerarCheckboxes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gerarCheckboxes();
            }
        });
    }

    private void gerarCheckboxes() {
        String nome = editNome.getText().toString();
        linearLayoutCheckboxes.removeAllViews(); // Limpa os CheckBoxes anteriores

        for (int i = 0; i < nome.length(); i++) {
            CheckBox checkBox = new CheckBox(this);
            checkBox.setText(String.valueOf(nome.charAt(i)));
            linearLayoutCheckboxes.addView(checkBox);
        }
    }
}
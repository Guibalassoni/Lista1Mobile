package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Exercicio1Activity extends AppCompatActivity {

    private EditText editNome;
    private EditText editIdade;
    private Button buttonVerificar;
    private TextView textResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.exercicio_1);

        editNome = findViewById(R.id.editNome);
        editIdade = findViewById(R.id.editIdade);
        buttonVerificar = findViewById(R.id.buttonVerificar);
        textResultado = findViewById(R.id.textResultado);

        buttonVerificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = editNome.getText().toString();
                String idadeStr = editIdade.getText().toString();

                if (!idadeStr.isEmpty()) {
                    int idade = Integer.parseInt(idadeStr);
                    if (idade >= 18) {
                        textResultado.setText(nome + " é maior de idade.");
                    } else {
                        textResultado.setText(nome + " é menor de idade.");
                    }
                } else {
                    textResultado.setText("Por favor, insira a idade.");
                }
            }
        });
    }
}
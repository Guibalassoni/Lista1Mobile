package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class PreferenciasActivity extends AppCompatActivity {

    private CheckBox checkNotificacoes, checkModoEscuro, checkLembrarLogin;
    private Button buttonSalvarPreferencias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preferencias);

        checkNotificacoes = findViewById(R.id.checkNotificacoes);
        checkModoEscuro = findViewById(R.id.checkModoEscuro);
        checkLembrarLogin = findViewById(R.id.checkLembrarLogin);
        buttonSalvarPreferencias = findViewById(R.id.buttonSalvarPreferencias);

        buttonSalvarPreferencias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exibirPreferencias();
            }
        });
    }

    private void exibirPreferencias() {
        StringBuilder preferencias = new StringBuilder();

        if (checkNotificacoes.isChecked()) preferencias.append("Receber notificações, ");
        if (checkModoEscuro.isChecked()) preferencias.append("Modo escuro, ");
        if (checkLembrarLogin.isChecked()) preferencias.append("Lembrar login, ");

        if (preferencias.length() > 0) {
            preferencias.delete(preferencias.length() - 2, preferencias.length()); // Remove a última vírgula e espaço
            Toast.makeText(this, "Preferências: " + preferencias.toString(), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Nenhuma preferência foi escolhida", Toast.LENGTH_SHORT).show();
        }
    }
}
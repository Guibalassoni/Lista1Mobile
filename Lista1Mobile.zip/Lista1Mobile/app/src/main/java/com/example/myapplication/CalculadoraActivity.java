package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CalculadoraActivity extends AppCompatActivity {

    private EditText editValor1;
    private EditText editValor2;
    private Button buttonAdicao;
    private Button buttonSubtracao;
    private Button buttonMultiplicacao;
    private Button buttonDivisao;
    private TextView textResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora);

        editValor1 = findViewById(R.id.editValor1);
        editValor2 = findViewById(R.id.editValor2);
        buttonAdicao = findViewById(R.id.buttonAdicao);
        buttonSubtracao = findViewById(R.id.buttonSubtracao);
        buttonMultiplicacao = findViewById(R.id.buttonMultiplicacao);
        buttonDivisao = findViewById(R.id.buttonDivisao);
        textResultado = findViewById(R.id.textResultado);

        buttonAdicao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcular("+");
            }
        });

        buttonSubtracao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcular("-");
            }
        });

        buttonMultiplicacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcular("*");
            }
        });

        buttonDivisao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcular("/");
            }
        });
    }

    private void calcular(String operacao) {
        String valor1Str = editValor1.getText().toString();
        String valor2Str = editValor2.getText().toString();

        if (!valor1Str.isEmpty() && !valor2Str.isEmpty()) {
            double valor1 = Double.parseDouble(valor1Str);
            double valor2 = Double.parseDouble(valor2Str);
            double resultado = 0;

            switch (operacao) {
                case "+":
                    resultado = valor1 + valor2;
                    break;
                case "-":
                    resultado = valor1 - valor2;
                    break;
                case "*":
                    resultado = valor1 * valor2;
                    break;
                case "/":
                    if (valor2 != 0) {
                        resultado = valor1 / valor2;
                    } else {
                        textResultado.setText("Erro: Divisão por zero!");
                        return;
                    }
                    break;
            }

            textResultado.setText("Resultado: " + resultado);
        } else {
            textResultado.setText("Por favor, insira ambos os valores.");
        }
    }
}